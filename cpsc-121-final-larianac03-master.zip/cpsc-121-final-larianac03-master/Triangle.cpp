// Ariana Contreras
// CPSC 1221-03
// Final
// 2020-5-14
// larianac03@csu.fullerton.edu
//
// What does this program do? What is it's title?
// forms a polygon and prints its values
//

#include "Triangle.hpp"


// Don't forget to call the parent class' constructor
Triangle::Triangle(float side_length) : Polygon(3, side_length)
{
  _side_length = side_length;
}

float Triangle::area( ) const
{
  float _area = (SQRT_3 / 4) * (_side_length * _side_length);
  return _area;
}

std::ostream& Triangle::write(std::ostream& out) const
{
  out << "Triangle(side_length = " << _side_length << ")";
  return out;
}

std::ostream& operator<<(std::ostream& out, const Triangle& t)
{
  return t.write(out);
}
