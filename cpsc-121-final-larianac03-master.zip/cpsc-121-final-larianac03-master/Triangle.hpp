// Ariana Contreras
// CPSC 1221-03
// Final
// 2020-5-14
// larianac03@csu.fullerton.edu
//
// What does this program do? What is it's title?
// forms a polygon and prints its values
//

#include <iostream>

#include "Polygon.hpp"

#ifndef _TRIANGLE_HPP_
#define _TRIANGLE_HPP_

// This class represents equilateral, convex triangle.
// A triangle has 3 sides.
class Triangle : public Polygon{

private:
  float _side_length = 0;

public:
  Triangle(float side_length);
  float area( ) const;                //virtual float area();
  virtual std::ostream& write(std::ostream& out) const;
};

std::ostream& operator<<(std::ostream& out, const Triangle& t);

#endif
