// Ariana Contreras
// CPSC 1221-03
// Final
// 2020-5-14
// larianac03@csu.fullerton.edu
//
// What does this program do? What is it's title?
// forms a polygon and prints its values
//

#include <iostream>
#include <fstream>
#include "Polygon.hpp"
#include "Octagon.hpp"
#include "Triangle.hpp"

using namespace std;

int main(int argc, char* argv[]){
  ifstream input_file;
  Polygon *my_polygon;
  int shape_type = 0;
  float size = 0.0;

  input_file.open(argv[1], ios::in);
  if(!input_file.is_open( ))
  {
    cerr << "Couldn't open " << argv[1] << "; exiting\n";
    exit(1);
  }

  input_file >> shape_type;
  input_file >> size;

  switch(shape_type){
    case 3:
    // Triangle
    my_polygon = new Triangle (size);
    break;

    case 8:
    // Octagon
    my_polygon = new Octagon (size);
    break;

    default:
    cout << "Unrecognized polygon type. Existing." << endl;
    exit(1);
    break;

  };

  cout << *my_polygon << " has an area of " << my_polygon->area( ) << endl;

  return 0;
}
